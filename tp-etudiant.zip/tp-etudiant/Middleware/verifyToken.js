const jwt = require('jsonwebtoken');

module.exports = (req, res, next) => {
  const token = req.cookies.token;

  // 🔒 Vérifie si le token est présent
  if (!token) {
    console.warn('⚠️ Token manquant : accès refusé.');
    return res.redirect('/login');
  }

  try {
    // ✅ Vérification du token avec la clé secrète
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    // 🔐 Attache les infos de l’utilisateur à la requête
    req.user = decoded;

    // ✅ Poursuit la chaîne middleware
    next();
  } catch (err) {
    console.error('⛔ Token invalide ou expiré :', err.message);
    res.clearCookie('token'); // Supprime le cookie invalide
    return res.redirect('/login');
  }
};
