// middleware/authMiddleware.js
module.exports = function (req, res, next) {
  if (!req.session || !req.session.user) {
    return res.redirect('/login'); // ou renvoyer un 401 si API
  }

  // Passer l'utilisateur dans req.user pour les views
  req.user = req.session.user;
  next();
};
