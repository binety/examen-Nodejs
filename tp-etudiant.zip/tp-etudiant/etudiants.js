const express = require('express');
const router = express.Router();
const db = require('./models/db');
const auth = require('./Middleware/auth'); // middleware avec rôle (ex: admin)
const { authenticate, authorizeRole } = require('./Middleware/auth');
const verifyToken = require('./Middleware/verifyToken');
const authMiddleware = require('./Middleware/authMiddleware');
const etudiantRoutes = require('./routes/etudiants');


// Tous les étudiants (protégé par token)
router.post('/', verifyToken, (req, res) => {
  const { matricule, nom, prenom } = req.body;

  if (!matricule || !nom || !prenom) {
    return res.status(400).send('Tous les champs sont requis');
  }

  db.query('INSERT INTO etudiants (matricule, nom, prenom) VALUES (?, ?, ?)',
    [matricule, nom, prenom],
    (err, result) => {
      if (err) {
        console.error(err);
        return res.status(500).send('Erreur serveur');
      }
      res.status(201).send('Étudiant ajouté');
    }
  );
});



// Rechercher un étudiant (token requis)
router.get('/search/:nom', verifyToken, (req, res) => {
    db.query("SELECT * FROM etudiants WHERE nom LIKE ?", [`%${req.params.nom}%`], (err, results) => {
        if (err) return res.status(500).json({ error: err });
        res.json(results);
    });
});

// Ajouter un étudiant (admin uniquement)
router.post('/', authenticate, authorizeRole('admin'), (req, res) => {
    const { nom, prenom, age } = req.body;
    db.query("INSERT INTO etudiants (nom, prenom, age) VALUES (?, ?, ?)", [nom, prenom, age], (err, result) => {
        if (err) return res.status(500).send(err);
        res.status(201).send('Étudiant ajouté');
    });
});

// Modifier un étudiant (admin uniquement)
router.put('/:id', authenticate, authorizeRole('admin'), (req, res) => {
    const { nom, prenom, age } = req.body;
    db.query("UPDATE etudiants SET nom = ?, prenom = ?, age = ? WHERE id = ?", [nom, prenom, age, req.params.id], (err) => {
        if (err) return res.status(500).json({ error: err });
        res.json({ message: 'Étudiant modifié' });
    });
});

// Supprimer un étudiant (admin uniquement)
router.delete('/:id', authenticate, authorizeRole('admin'), (req, res) => {
    db.query("DELETE FROM etudiants WHERE id = ?", [req.params.id], (err) => {
        if (err) return res.status(500).json({ error: err });
        res.json({ message: 'Étudiant supprimé' });
    });
});

// Ajouter un étudiant (protégé)
router.post('/', verifyToken, (req, res) => {
  const { matricule, nom, prenom } = req.body;

  db.query(
    'INSERT INTO etudiants (matricule, nom, prenom) VALUES (?, ?, ?)',
    [matricule, nom, prenom],
    (err, result) => {
      if (err) return res.status(500).send(err);
      res.redirect('/'); // ou res.status(201).send("Ajouté") si via fetch
    }
  );
});

module.exports = router;


router.get('/ajouter', authMiddleware, (req, res) => {
  if (req.user.role !== 'admin') {
    return res.status(403).send('Accès interdit');
  }
  res.render('add', { user: req.user });
});

router.get('/modifier', authMiddleware, (req, res) => {
  if (req.user.role !== 'admin') {
    return res.status(403).send('Accès interdit');
  }
  // récupérer l'étudiant, puis
  res.render('edit', { user: req.user, etudiant: data });
});

