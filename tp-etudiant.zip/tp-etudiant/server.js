const express = require('express');
const dotenv = require('dotenv');
const path = require('path');
const cookieParser = require('cookie-parser');
const db = require('./models/db');
const verifyToken = require('./Middleware/verifyToken');
const authRoutes = require('./routes/Auth');
const etudiantRoutes = require('./routes/etudiants');

dotenv.config();
const app = express();

app.use(cookieParser());
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use('/api/auth', authRoutes);
app.use('/api/etudiants', etudiantRoutes);

// Auth pages
app.get('/register', (req, res) => res.render('register'));
app.get('/login', (req, res) => res.render('login'));
app.get('/logout', (req, res) => {
  res.clearCookie('token');
  res.redirect('/login');
});

// Homepage protected and pass user
app.get('/', verifyToken, (req, res) => {
  db.query('SELECT * FROM etudiants', (err, results) => {
    if (err) return res.status(500).send('Erreur DB');
    res.render('index', { etudiants: results, user: req.user });
  });
});

// Form add student (admin only)
app.get('/ajouter', verifyToken, (req, res) => {
  if (req.user.role !== 'admin') return res.status(403).send('Accès interdit');
  res.render('add', { user: req.user });
});

// Form edit student (admin only)
app.get('/modifier', verifyToken, (req, res) => {
  if (req.user.role !== 'admin') return res.status(403).send('Accès interdit');
  res.render('edit', { user: req.user });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`✅ Serveur démarré sur http://localhost:${PORT}`));
