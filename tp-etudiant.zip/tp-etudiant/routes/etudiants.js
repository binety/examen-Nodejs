const express = require('express');
const router = express.Router();
const db = require('../models/db');
const verifyToken = require('../Middleware/verifyToken');

function authorizeRole(role) {
  return (req, res, next) => {
    if (!req.user || req.user.role !== role) {
      return res.status(403).json({ message: 'Accès interdit' });
    }
    next();
  };
}

// GET all students
router.get('/', verifyToken, (req, res) => {
  db.query('SELECT * FROM etudiants', (err, results) => {
    if (err) return res.status(500).json({ error: 'Erreur serveur' });
    res.json(results);
  });
});

// POST add student (admin only)
router.post('/', verifyToken, authorizeRole('admin'), (req, res) => {
  const { matricule, nom, prenom, date_naissance, universite, filiere, classe, nationalite, sexe } = req.body;

  if (!matricule || !nom || !prenom) {
    return res.status(400).json({ error: 'Champs obligatoires manquants' });
  }

  const sql = `
    INSERT INTO etudiants (matricule, nom, prenom, date_naissance, universite, filiere, classe, nationalite, sexe)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `;

  db.query(sql, [matricule, nom, prenom, date_naissance, universite, filiere, classe, nationalite, sexe], (err) => {
    if (err) return res.status(500).json({ error: 'Erreur lors de l’ajout' });
    res.status(201).json({ message: 'Étudiant ajouté avec succès' });
  });
});

// PUT modify student (admin only)
router.put('/:matricule', verifyToken, authorizeRole('admin'), (req, res) => {
  const { matricule } = req.params;
  const data = req.body;

  db.query('UPDATE etudiants SET ? WHERE matricule = ?', [data, matricule], (err) => {
    if (err) return res.status(500).json({ error: 'Erreur de mise à jour' });
    res.json({ message: 'Étudiant modifié avec succès' });
  });
});

// DELETE student (admin only)
router.delete('/:matricule', verifyToken, authorizeRole('admin'), (req, res) => {
  const { matricule } = req.params;

  db.query('DELETE FROM etudiants WHERE matricule = ?', [matricule], (err) => {
    if (err) return res.status(500).json({ error: 'Erreur de suppression' });
    res.json({ message: 'Étudiant supprimé' });
  });
});

module.exports = router;
